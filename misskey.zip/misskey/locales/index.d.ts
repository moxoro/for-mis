declare const locales: Record<string, object>;

export default locales;

export const primaries: Record<string, string>;
