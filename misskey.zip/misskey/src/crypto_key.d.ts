export function extractPublic(keypair: string): string;
export function generate(): string;
