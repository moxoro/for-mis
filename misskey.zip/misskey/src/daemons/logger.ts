import Logger from '../services/logger';

const logger = new Logger('daemons');

export = logger;
