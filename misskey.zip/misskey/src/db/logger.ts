import Logger from '../services/logger';

export const dbLogger = new Logger('db');
