import load from './load';

export default load();
