type Acct = {
	username: string;
	host: string;
};

export default Acct;
