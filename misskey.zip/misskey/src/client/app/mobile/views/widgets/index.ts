import Vue from 'vue';

import wActivity from './activity.vue';
import wProfile from './profile.vue';

Vue.component('mkw-activity', wActivity);
Vue.component('mkw-profile', wProfile);
