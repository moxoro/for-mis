<template>
<div class="mkw-instance">
	<ui-container>
		<mk-instance/>
	</ui-container>
</div>
</template>

<script lang="ts">
import define from '../../../common/define-widget';
export default define({
	name: 'instance'
});
</script>
