import * as NProgress from 'nprogress';
NProgress.configure({
	trickleSpeed: 500,
	showSpinner: false
});

const root = document.documentElement;

export default {
	start: () => {
		root.classList.add('progress');
		NProgress.start();
	},
	done: () => {
		root.classList.remove('progress');
		NProgress.done();
	},
	set: val => {
		NProgress.set(val);
	}
};
