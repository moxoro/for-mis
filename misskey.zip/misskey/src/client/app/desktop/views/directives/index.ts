import Vue from 'vue';

import userPreview from './user-preview';

Vue.directive('userPreview', userPreview);
Vue.directive('user-preview', userPreview);
