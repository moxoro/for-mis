<template>
<div class="mkw-notifications">
	<ui-container :show-header="!props.compact">
		<template #header><fa :icon="['fal', 'bell']"/>{{ $t('title') }}</template>
		<!-- <button #func :title="$t('title')" @click="settings"><fa :icon="['fal', 'cog']"/></button> -->

		<mk-notifications :class="$style.notifications"/>
	</ui-container>
</div>
</template>

<script lang="ts">
import define from '../../../common/define-widget';
import i18n from '../../../i18n';

export default define({
	name: 'notifications',
	props: () => ({
		compact: false
	})
}).extend({
	i18n: i18n('desktop/views/widgets/notifications.vue'),
	methods: {
		settings() {
			alert('not implemented yet');
		},
		func() {
			this.props.compact = !this.props.compact;
			this.save();
		}
	}
});
</script>

<style lang="stylus" module>
.notifications
	max-height 450px
	overflow auto
</style>
